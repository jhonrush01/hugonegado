<?php require_once 'engine/init.php'; include 'layout/overall/header.php'; ?>

<h1>Contact</h1>
<p>TODO: Edit the contact details here.</p>

<?php include 'layout/overall/footer.php'; ?>