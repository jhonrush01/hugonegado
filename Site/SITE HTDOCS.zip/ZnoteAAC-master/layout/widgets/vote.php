<div class="sidebar">
	<h2>Vote for us!</h2>
	<div class="inner">
		<form type="submit" action="voting.php" method="GET">
			Get points by voting at OTServers.eu
			<input type="submit" value="Vote">
		</form>
	</div>
</div>
