<?php include 'layout/overall/header.php'; ?>

<h1>Welcome</h1>
<p>Hello, this is a small, plain and epic design? Lets hope so.</p>

<?php include 'layout/overall/footer.php'; ?>