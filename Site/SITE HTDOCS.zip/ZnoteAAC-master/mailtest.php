<?php
//mail('TEST', 'Hello!', 'Hello, this is a test email.', 'From: Znote OT AAC.');
?>